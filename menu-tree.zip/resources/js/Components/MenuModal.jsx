// resources/js/Components/MenuModal.jsx
import React from 'react'

export default function MenuModal({ visible, onClose, onSubmit, data, setData, errors, title }) {
  if (!visible) return null

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-30 z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md shadow-md">
        <h2 className="text-xl font-semibold mb-4">{title}</h2>

        <form onSubmit={onSubmit}>
          <div className="mb-4">
            <label className="block text-sm font-medium">Name</label>
            <input
              value={data.name || ''}
              onChange={(e) => setData('name', e.target.value)}
              className="w-full p-2 border rounded"
              required
            />
            {errors.name && <div className="text-red-500 text-sm">{errors.name}</div>}
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium">Parent ID</label>
            <input
              value={data.parent_id || ''}
              onChange={(e) => setData('parent_id', e.target.value)}
              className="w-full p-2 border rounded"
              readOnly
            />
          </div>

          <div className="flex justify-end">
            <button type="button" onClick={onClose} className="mr-2 text-sm">Batal</button>
            <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
              Simpan
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
