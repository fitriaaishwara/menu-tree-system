export default function Home() {
  return <h1 className="text-2xl font-bold text-center mt-10">Menu Tree App 🚀</h1>;
}
