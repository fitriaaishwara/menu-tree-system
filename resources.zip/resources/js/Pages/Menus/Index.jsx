import React, { useState } from 'react';
import { useForm, router } from '@inertiajs/react';
import MenuModal from '@/Components/MenuModal';
import Layout from '@/Layouts/Layout';
import '../../../css/app.css'

// function Index({ menus }) {
//   const { data, setData, post, reset, errors } = useForm({
//     name: '',
//     parent_id: null,
//   });

//   const [showModal, setShowModal] = useState(false);
//   const [modalData, setModalData] = useState({ id: '', name: '', parent_id: '' });
//   const [modalType, setModalType] = useState('add');

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     post('/menus', {
//       onSuccess: () => reset(),
//     });
//   };

//   const handleDelete = (id) => {
//     if (confirm('Yakin ingin menghapus menu ini?')) {
//       router.delete(`/menus/${id}`);
//     }
//   };

//   const handleEdit = (menu) => {
//     setModalData({ ...menu });
//     setModalType('edit');
//     setShowModal(true);
//   };

//   const handleAddSubmenu = (parentId) => {
//     setModalData({ id: '', name: '', parent_id: parentId });
//     setModalType('add');
//     setShowModal(true);
//   };

//   const handleModalSubmit = (e) => {
//     e.preventDefault();
//     if (modalType === 'edit') {
//       router.put(`/menus/${modalData.id}`, modalData, {
//         onSuccess: () => setShowModal(false),
//       });
//     } else {
//       router.post('/menus', modalData, {
//         onSuccess: () => setShowModal(false),
//       });
//     }
//   };

//   const renderTree = (items) => {
//     return (
//       <ul className="ml-4 list-disc">
//         {items.map((menu) => (
//           <li key={menu.id} className="mb-1">
//             <div className="flex justify-between items-center">
//               <span>{menu.name}</span>
//               <div className="space-x-2">
//                 <button onClick={() => handleEdit(menu)} className="text-blue-500 text-sm">Edit</button>
//                 <button onClick={() => handleAddSubmenu(menu.id)} className="text-green-600 text-sm">+ Submenu</button>
//                 <button onClick={() => handleDelete(menu.id)} className="text-red-500 text-sm">Delete</button>
//               </div>
//             </div>
//             {menu.children && menu.children.length > 0 && renderTree(menu.children)}
//           </li>
//         ))}
//       </ul>
//     );
//   };

//   return (
//     <div className="p-6 max-w-4xl mx-auto">
//       <h1 className="text-2xl font-bold mb-4">Menu Tree</h1>

//       {/* Form Tambah Menu Parent */}
//       <form onSubmit={handleSubmit} className="mb-6">
//         <div className="flex gap-4 items-end">
//           <div className="flex-1">
//             <label className="block text-sm font-medium">Nama Menu</label>
//             <input
//               type="text"
//               className="w-full border p-2 rounded"
//               value={data.name}
//               onChange={(e) => setData('name', e.target.value)}
//               required
//             />
//             {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
//           </div>
//           <button
//             type="submit"
//             className="bg-blue-600 text-white px-4 py-2 rounded"
//           >
//             Tambah Menu
//           </button>
//         </div>
//       </form>

//       {/* Tampilkan Menu Tree */}
//       <div>{renderTree(menus)}</div>

//       {/* Modal Tambah/Edit Submenu */}
//       <MenuModal
//         visible={showModal}
//         title={modalType === 'edit' ? 'Edit Menu' : 'Tambah Submenu'}
//         onClose={() => setShowModal(false)}
//         onSubmit={handleModalSubmit}
//         data={modalData}
//         setData={(key, value) => setModalData((prev) => ({ ...prev, [key]: value }))}
//         errors={errors}
//       />
//     </div>
//   );
// }
// export default Index;
export default function Index() {
return (
  <div className="min-h-screen flex items-center justify-center bg-blue-100">
    <div className="p-8 bg-white rounded-2xl shadow-md">
      <h1 className="text-4xl font-bold mb-4 text-blue-700">Tailwind Aktif 🎉</h1>
      <p className="text-lg text-gray-700">
        Kalau kamu bisa lihat warna dan style ini, berarti Tailwind berhasil!!
      </p>
    </div>
  </div>
);
}
