import React from 'react';
import { Link } from '@inertiajs/react';

export default function Layout({ children }) {
  return (
    <div className="min-h-screen flex">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-800 text-white flex flex-col">
        <div className="p-4 text-xl font-bold border-b border-gray-700">My App</div>
        <nav className="flex-1 p-4 space-y-2">
          <Link href="/menus" className="block hover:bg-gray-700 p-2 rounded">
            Menu Tree
          </Link>
          {/* Tambah menu lain di sini */}
        </nav>
      </aside>

      {/* Konten Utama */}
      <div className="flex-1 flex flex-col">
        {/* Topbar */}
        <header className="bg-white shadow px-6 py-4 flex justify-between items-center">
          <h1 className="text-lg font-semibold">Dashboard</h1>
          <div>
            <span className="text-sm text-gray-600">Hello, Admin</span>
          </div>
        </header>

        {/* Isi halaman */}
        <main className="p-6 bg-gray-100 flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}


